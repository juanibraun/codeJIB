/* 
 * File:   bfs.h
 * Author: juanignaciobraun
 *
 * Created on May 14, 2013, 8:27 PM
 */

#include "tree.h"



void dfs_rec(tree* t, node* n);

void dfs_it(tree* t, node* n);
